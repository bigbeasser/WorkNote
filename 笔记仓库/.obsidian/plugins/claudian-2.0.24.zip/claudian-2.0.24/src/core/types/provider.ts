export type ProviderId = string;
